The original submission that you are polishing: Unity Project 2: First Person Game)

Any bug fixes or gameplay changes that differ from this version
- fixed the weird enemy AI, they walk around now and there's more of them
- the screen is now limited y direction wise so you can't look 180 degrees up and down
- knives are less buggy
- knives actually kill amoguses now

Any visual improvements that you made to the game
- new map, a little more minimalistic
- death screen!/win screen, whatever you wanna call it

Instructions on how to play (controls)
- WASD to move
- left click to throw knife
- hold shift to run